# CNC Router — Mach3 Firmware Package
## USB 100kHz Controller Board · 4-Axis · Dual-X Gantry · 2.2kW Spindle

---

## What's In This Package

| File | Purpose |
|------|---------|
| `Mach3Mill.xml` | Machine profile — axis tuning, pin mapping, spindle config |
| `macros/M1000.m1s` | Startup init macro (auto-runs on profile load) |
| `macros/M_Home.m1s` | Full homing sequence — Z → X+A → Y |
| `macros/M3.m1s` | Spindle ON with coolant check + ramp wait |
| `macros/M5.m1s` | Spindle OFF with coast-down delay |
| `macros/M37.m1s` | Auto tool-length setter (Z-probe) |
| `macros/M_EStop.m1s` | E-Stop handler — kills spindle + all outputs |

---

## Hardware Wiring Reference

### Driver Pin Mapping (DM542T × 4)

| Axis | Motor | Step Pin | Dir Pin | Board Connector |
|------|-------|----------|---------|----------------|
| X1 | Motor 0 | Pin 2 | Pin 3 | X / Axis 0 |
| Y | Motor 1 | Pin 4 | Pin 5 | Y / Axis 1 |
| Z | Motor 2 | Pin 6 | Pin 7 | Z / Axis 2 |
| X2 (slave) | Motor 3 | Pin 8 | Pin 9 | A / Axis 3 |

**X2 motor direction is reversed** in the XML (`<_Reversed>1</_Reversed>`) — the A-axis motor faces the opposite direction on the gantry, so its DIR signal is flipped to make both X motors move the gantry in the same physical direction.

### DM542T Driver Switch Settings (for NEMA 23, 5.0A, 3.0Nm)

| Switch | Position | Function |
|--------|----------|---------|
| SW1 | ON | Current = 4.5A peak (matching 5.0A motor) |
| SW2 | ON | (see current table) |
| SW3 | OFF | (see current table) |
| SW4 | OFF | 1600 pulses/rev (half-step) |
| SW5 | ON | (see microstep table) |
| SW6 | OFF | (see microstep table) |
| SW7 | ON | Standby current = 50% (motor doesn't overheat at rest) |
| SW8 | OFF | |

> **Verify with your DM542T manual** — switch positions vary slightly by revision.
> Target: **4.5A peak, 1600 steps/rev**.

### Input Wiring (24V opto-isolated inputs)

```
Board Input Pins (24V common rail required):

Pin 10  ──── X limit switch (NO contact) ──── 24V COM
Pin 11  ──── Y limit switch (NO contact) ──── 24V COM
Pin 12  ──── Z limit switch (NO contact) ──── 24V COM
Pin 13  ──── E-Stop button (NC contact)  ──── 24V COM
Pin 15  ──── Tool probe plate            ──── GND

Note: Limit switches are wired NO (Normally Open).
      E-Stop is wired NC (Normally Closed) — a broken wire = safe stop.
      The XML sets Pin13 ActiveLow=1 for NC logic.
```

### Spindle VFD Wiring (2.2kW, 110V)

```
Board → VFD:
  PWM output (0-10V analog) → VI (analog speed input)
  GND                       → ACM (analog common)
  Output1 relay (NO)        → FWD + CM (start/stop)

VFD settings to configure on the inverter panel:
  Pd000 = 1   (allow parameter write)
  Pd001 = 1   (run via terminal, not keypad)
  Pd002 = 1   (frequency via analog input VI)
  Pd004 = 400 (max frequency Hz — matches spindle 24000RPM at 400Hz)
  Pd005 = 400 (intermediate frequency)
  Pd007 = 0   (min frequency)
  Pd011 = 3   (min RPM freq, ~3000 RPM)
  Pd014 = 3   (acceleration time, seconds — match M3.m1s SpindleStartDelay)
  Pd015 = 5   (deceleration time, seconds — match M5.m1s coast delay)
  Pd070 = 1   (analog input VI active)
  Pd072 = 10  (max analog voltage = 10V)
  Pd073 = 0   (min analog voltage = 0V)
```

### Relay Module Wiring (4-channel, 5V coil)

```
Board Output → Relay → Load:
  Out1 (Pin1)  → Relay CH1 → VFD FWD/CM  (spindle on/off)
  Out2 (Pin14) → Relay CH2  → VFD REV/CM  (spindle reverse, optional)
  Out3 (Pin16) → Relay CH3  → Coolant pump
  Out4 (Pin17) → Relay CH4  → Spare / air blast
```

---

## Software Installation

### Step 1 — Install Mach3
1. Download Mach3 v3.043.066 (or latest) from machsupport.com
2. Run installer, accept defaults
3. Install to `C:\Mach3\`

### Step 2 — Install USB Board Plugin
1. Download `BL-UsbMach-V22.dll` (or the plugin matching your board variant)
2. Copy to `C:\Mach3\Plugins\`
3. Connect the USB controller board
4. Windows should auto-install the USB driver; if not, install from the board's CD/download

### Step 3 — Install Profile
1. Copy `Mach3Mill.xml` to `C:\Mach3\`
2. Copy all files from `macros\` folder to `C:\Mach3\macros\Mach3Mill\`
   (create the `Mach3Mill` folder if it doesn't exist)

### Step 4 — First Launch
1. Launch Mach3
2. Select profile: `Mach3Mill` from the profile list
3. Go to **Config → Config Plugins** → enable the USB board plugin
4. Restart Mach3

### Step 5 — Verify Inputs
1. **Diagnostics tab** in Mach3 → watch the input LEDs
2. Manually trigger each limit switch — the corresponding LED should light
3. Press E-Stop — `EStop` LED should light, machine should halt
4. Check axis movement: **Jog** each axis slowly with keyboard arrows

### Step 6 — Calibrate Steps/mm
The XML uses calculated steps/mm = **320** (1600 steps/rev ÷ 5mm pitch).
To verify and trim:
1. Mark a reference position
2. Command `G0 X100` in MDI
3. Measure actual travel with calipers
4. Settings tab → **Set Steps Per Unit** → enter 100, then measured distance
5. Mach3 recalculates and saves the correction

---

## Steps Per mm Calculation

```
Formula:  steps/mm = (steps_per_rev × microstepping) / ball_screw_pitch_mm

Your machine:
  steps_per_rev    = 200 (standard stepper)
  microstepping    = 8   (half-step = 200 × 8 = 1600 pulses/rev on DM542T)
  ball_screw_pitch = 5mm (1605 = 16mm dia, 5mm pitch)

  steps/mm = 1600 / 5 = 320 steps/mm  ✓

Maximum speed check:
  At 320 steps/mm and 3000 mm/min:
  pulse_hz = 320 × (3000/60) = 16,000 Hz
  Board limit = 100,000 Hz → headroom: 6×
  You can safely push to ~15,000 mm/min if mechanics allow.
```

---

## Axis Travel Limits

| Axis | Min (mm) | Max (mm) | Ball Screw Length |
|------|----------|----------|-------------------|
| X | 0 | 650 | 650mm |
| Y | 0 | 700 | 700mm |
| Z | -100 | 0 | ~100mm travel |

Z is configured so that Z=0 = top of travel (homed position).
Negative Z = tool moving into the work.

---

## Macro Reference

| Macro | How to Run | What it does |
|-------|-----------|-------------|
| `M1000` | Auto on startup | Safety init, sets G21/G90/G94 |
| `M_Home` | MDI: `M_Home` or screen button | Homes Z→X+A→Y with confirmation |
| `M3 S12000` | G-code: `M3 S12000` | Starts spindle at 12000 RPM, waits 3s ramp |
| `M5` | G-code: `M5` | Stops spindle, waits 5s coast-down |
| `M37` | MDI: `M37` | Auto tool length probe on Pin15 |
| `M_EStop` | Auto on E-Stop trigger | Kills all outputs, prompts operator |

---

## Typical Job Startup Sequence

```
1. Power on machine (PSU → drivers → spindle VFD)
2. Check cooling water level and flow
3. Launch Mach3 → profile auto-inits (M1000)
4. Home all axes:  Alt+Home  or run M_Home
5. Load G-code file
6. Mount workpiece, set XY zero manually (or use fixture offsets)
7. Run M37 for Z tool length (probe over setter plate)
8. Verify toolpath with Toolpath display
9. Start: Cycle Start
```

---

## Tuning Notes

**Acceleration too high?** Symptoms: lost steps, grinding noise on direction changes.
→ Lower `_Acceleration` in XML. Start at 200 mm/s², increase slowly.

**Velocity too high?** Symptoms: stalling on rapids, position errors.
→ Lower `_Velocity`. Check pulse Hz is within board limit.

**Backlash?** Set `_BacklashEnabled>1` and measure with a dial indicator.
→ Typical for 1605 ballscrews: 0.01–0.05mm. Enter measured value.

**Spindle won't ramp speed via Mach3?**
→ Verify VFD Pd001=1, Pd002=1, Pd070=1, and 0-10V wire is on VI/ACM.

---

## Safety Checklist Before Every Session

- [ ] E-Stop button is accessible and functional
- [ ] All limit switches wired and triggering in Diagnostics
- [ ] Cooling water flowing (check pump, tubing, reservoir level)
- [ ] Workpiece securely clamped
- [ ] Tool is properly seated in collet, collet nut tight
- [ ] Z soft limit prevents plunge below stock
- [ ] No loose wiring near moving axes
